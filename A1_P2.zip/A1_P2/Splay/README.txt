Tuesday, Feb 24 11:59 p.m.
Assignment 1_P2
By: Ethan Bohling

Functions done:
DeleteNode(): Iteratively searches for node to be deleted. Then, it removes that node and calls the splay function to restore splay tree properties.
SearchNode(): Iteratively searches for a node. Then, it calculates the average search depth for a specified splay tree selected from the options below.
SemiSplay(): Recursively Splays a tree as it's being created until a specified depth limit.
WeightedSplay(): Recursively Splays a tree as it's being created and provides and updates a nodes weight

How to compile/run program
To compile: type make in terminal
To run: type ./aout