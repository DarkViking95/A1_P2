#include "splayv2.h"
#include "customErrorClass.h"

SplayTree::SplayTree()
{
    root = nullptr; 
    int rotationCount = 0;
    int totalSearchDepth = 0;
    int searchCount = 0;
}

// aka Zig
SplayTree::Node* SplayTree::rotateRight(Node* x) {
    rotationCount++;
    Node* y = x->left;
    x->left = y->right;
    y->right = x;

    return y;
}

// aka Zag
SplayTree::Node* SplayTree::rotateLeft(Node* x) {
    rotationCount++;
    Node* y = x->right;
    x->right = y->left;
    y->left = x;

    return y;
}

// Splaying :)
SplayTree::Node* SplayTree::splay(Node* root, int key) 
{
    if (root == nullptr || root->key == key)
    {
        return root;
    }

    // key in left subtree
    if (key < root->key)
    {
        if (root->left == nullptr)
            return root;
        
        // Zig Zig
        if (key < root->left->key)
        {
            root->left->left = splay(root->left->left, key);
            root = rotateRight(root);
        }
        // Zig Zag
        else if (key > root->left->key)
        {
            root->left->right = splay(root->left->right, key);
            if(root->left->right != nullptr)
                root->left = rotateLeft(root->left);
        }

        if (root->left == nullptr)
        {
            return root;
        }
        else
            return rotateRight(root);
        
    }

    // key in right subtree
    if (key > root->key)
    {
        if (root->right == nullptr)
            return root;
        
        // Zag Zag
        if (key > root->right->key)
        {
            root->right->right = splay(root->right->right, key);
            root = rotateLeft(root);
        }
        // Zag Zig
        else if (key < root->right->key)
        {
            root->right->left = splay(root->right->left, key);
            if(root->right->left != nullptr)
                root->right = rotateRight(root->right);
        }

        if (root->right == nullptr)
        {
            return root;
        }
        else
            return rotateLeft(root);
        
    }
}

SplayTree::Node* SplayTree::topDownSplay(Node* root, int key) 
{
    if (root == nullptr) 
        return nullptr;

    Node temp(0); 
    Node* leftTreeMax = &temp;
    Node* rightTreeMin = &temp;

    while (true) 
    {
        if (key < root->key) 
        {  
            if (root->left == nullptr) 
                break;

            if (key < root->left->key) {
                root = rotateRight(root);

                if (root->left == nullptr) 
                    break;
            }
            
            rightTreeMin->left = root;
            rightTreeMin = root;
            root = root->left;
        } 
        else if (key > root->key) 
        {
            if (root->right == nullptr) 
                break;

            if (key > root->right->key) {
                root = rotateLeft(root);

                if (root->right == nullptr) 
                    break;
            }
            
            leftTreeMax->right = root;
            leftTreeMax = root;
            root = root->right;
        } 
        else 
        {
            break;
        }
    }

    leftTreeMax->right = root->left;
    rightTreeMin->left = root->right;
    root->left = temp.right;
    root->right = temp.left;

    return root;
}

SplayTree::Node* SplayTree::semiSplay(Node* root, int key, int currentDepth, int depthLimit) 
{
    // The new base case: Stop if we hit the depth limit!
    if (root == nullptr || root->key == key || currentDepth >= depthLimit) 
    {
        return root;
    }

    if (key < root->key) 
    {
        if (root->left == nullptr) 
            return root;

        if (key < root->left->key) 
        {
            // Pass currentDepth + 2 because we are looking two levels down
            root->left->left = semiSplay(root->left->left, key, currentDepth + 2, depthLimit);
            root = rotateRight(root);
        
        } 
        else if (key > root->left->key) 
        {
            root->left->right = semiSplay(root->left->right, key, currentDepth + 2, depthLimit);
            
            if (root->left->right != nullptr) 
                root->left = rotateLeft(root->left);
        }
        return (root->left == nullptr) ? root : rotateRight(root);
    } 
    else 
    {
        if (root->right == nullptr) 
            return root;

        if (key < root->right->key) 
        {
            root->right->left = semiSplay(root->right->left, key, currentDepth + 2, depthLimit);
            
            if (root->right->left != nullptr)
                root->right = rotateRight(root->right);

        } 
        else if (key > root->right->key) 
        {
            root->right->right = semiSplay(root->right->right, key, currentDepth + 2, depthLimit);
            root = rotateLeft(root);
        }
        
        return (root->right == nullptr) ? root : rotateLeft(root);
    }
}

SplayTree::Node* SplayTree::insertNode(Node* root, int key) {
    
    if (root == nullptr)
    {
        return new Node(key);
    }

    root = splay(root, key);

    // key already exists
    if (root->key == key)
    {
        return root;
    }

     Node* newNode = new Node(key);

    if (key < root->key)
    {
        newNode->right = root;
        newNode->left = root->left;
        root->left = nullptr;
    }
    else
    {
        newNode->left = root;
        newNode->right = root->right;
        root->right = nullptr;
    }

    return newNode;
}

SplayTree::Node* SplayTree::weightedSplay(Node* root, int key) 
{
    // Base cases
    if (root == nullptr || root->key == key) 
        return root;

    if (key < root->key) 
    {
        if (root->left == nullptr) 
            return root;
        
        // Zig-Zig
        if (key < root->left->key) 
        {
            root->left->left = weightedSplay(root->left->left, key);
            // left-child >= root
            if (root->left->weight >= root->weight) 
            {
                root = rotateRight(root);
            }
        } 
        // Zig-Zag
        else if (key > root->left->key) 
        {
            root->left->right = weightedSplay(root->left->right, key);
            // right-child >= left-parent
            if (root->left->right != nullptr && root->left->right->weight >= root->left->weight) 
            {
                root->left = rotateLeft(root->left);
            }
        }

        // right-child >= right-parent
        if (root->left != nullptr && root->left->weight >= root->weight) 
        {
            root = rotateRight(root);
        }
        return root;
    } 
    else 
    {
        if (root->right == nullptr) 
            return root;

        // Zag-Zig
        if (key < root->right->key) 
        {
            root->right->left = weightedSplay(root->right->left, key);
            // right-child >= right-parent
            if (root->right->left != nullptr && root->right->left->weight >= root->right->weight) 
            {
                root->right = rotateRight(root->right);
            }
        } 
        // Zag-Zag
        else if (key > root->right->key) 
        {
            root->right->right = weightedSplay(root->right->right, key);
            // right-child >= root
            if (root->right->weight >= root->weight) 
            {
                root = rotateLeft(root);
            }
        }

        // right-child >= right-parent
        if (root->right != nullptr && root->right->weight >= root->weight) 
        {
            root = rotateLeft(root);
        }
        return root;
    }
}

SplayTree::Node* SplayTree::deleteNode(Node* root, int key) 
{
    if (root == nullptr) 
    {
        throw MyException("Tree and key does not exist");
    }

    // Option 1: Top-down Approach
    Node* temp = new Node(0); 
    Node* leftTreeMax = temp;
    Node* rightTreeMin = temp;

    while (true)
    {
        if (key < root->key)
        {
            if (root->left == nullptr) 
                break;

            // Zig Zig
            if (key < root->left->key)
            {
                root = rotateRight(root);
                if (root->left == nullptr) 
                    break;
            }

            // Link Right
            rightTreeMin->left = root;
            rightTreeMin = root;
            root = root->left;
        }
        else if (key > root->key)
        {
            if (root->right == nullptr) 
                break;

            // Zag Zag
            if (key > root->right->key)
            {
                root = rotateLeft(root);
                if (root->right == nullptr) 
                    break;
            }

            // Link Left
            leftTreeMax->right = root;
            leftTreeMax = root;
            root = root->right;
        }
        else
        {
            break; // Key found
        }
    }

    // Reassemble the tree
    leftTreeMax->right = root->left;
    rightTreeMin->left = root->right;
    root->left = temp->right;
    root->right = temp->left;

    delete temp; 

    // Option 2: Bottom-up Approach
    // To use this instead, comment out Option 1 above, and uncomment the next line

    //root = splay(root, key);

    // If the key wasn't found after splaying, throw an exception
    if (root->key != key)
    {
        throw MyException("Node does not exist");
    }

    // Root is the node to be deleted
    Node* leftSubtree = root->left;
    Node* rightSubtree = root->right;

    delete root;

    // Splay the largest node of the left subtree to its root (if it exists)
    if (leftSubtree != nullptr)
    {
        leftSubtree = splay(leftSubtree, key); 
    }

    // Attach the right subtree to the new root of the left subtree
    if (leftSubtree != nullptr)
    {
        leftSubtree->right = rightSubtree;
        return leftSubtree;
    }

    return rightSubtree;
}

void SplayTree::insert(int key) {
    root = insertNode(root, key);
}


void SplayTree::remove(int key) {
    root = deleteNode(root, key);
}

bool SplayTree::search(int key) 
{
    if (root == nullptr) 
    {
        throw MyException("Tree is empty");
    }

    // Count depth and update weight
    int currentDepth = 0;
    Node* temp = root;
    bool found = false;

    while (temp != nullptr) {
        if (key == temp->key) {
            found = true;
            temp->weight++; // Increment weight
            break;
        } else if (key < temp->key) {
            temp = temp->left;
            currentDepth++;
        } else {
            temp = temp->right;
            currentDepth++;
        }
    }

    if (found) {
        totalSearchDepth += currentDepth;
        searchCount++;
    } else {
        return false; 
    }

    // Choose one of the four options

    // Option 1: Bottom-Up Splay
    //root = splay(root, key); 


    // Option 2: Top-Down Splay
    //root = topDownSplay(root, key); 

    // Option 3: semiSplay
    //root = semiSplay(root, key, 0, 15);

    // Option 4: Weighted Splay
    root = weightedSplay(root, key);

    return true;
}

int SplayTree::getRotationCount() 
{
    return rotationCount;
}

int SplayTree::getAverageSearchDepth() 
{
    // Divide by zero check
    if (searchCount == 0) {
        throw MyException("Cannot divide by zero");
    }
    
    // Cast to double so we get a precise decimal
    return (double)totalSearchDepth / searchCount;
}

void SplayTree::printTree(Node* root, int space) {
    const int COUNT = 10; 

    if (root == nullptr) {
        return;
    }

    // Increase the distance between levels
    space += COUNT;

    // Print the right child first (to appear on top)
    printTree(root->right, space);

    // Print the current node after right child

    for (int i = COUNT; i < space; i++) {
        cout << " "; // Indentation for tree depth
    }
    cout << root->key << endl;

    // Print the left child
    printTree(root->left, space);
}

void SplayTree::display() {
    printTree(root, 0);
    cout << endl;
}
