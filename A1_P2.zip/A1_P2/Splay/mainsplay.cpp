#include <iostream>
#include <fstream>
#include <sstream>
#include "customErrorClass.h"
#include "splayv2.h"
using namespace std;





int main(int argc, char* argv[]) 
{
    SplayTree tree;
    string line;

    ifstream Command("accessPattern/working_set.txt");

    while(getline(Command, line))
    {
        stringstream ss(line);
        string value;

        ss >> value;
        int x = stoi(value);
        tree.insert(x);
    }

    Command.clear();
    Command.seekg(0, ios::beg);

    while(getline(Command, line))
    {
        stringstream ss(line);
        string value;

        ss >> value;
        int x = stoi(value);
        tree.search(x);
    } 

    cout << "Total rotations: " << tree.getRotationCount() << endl;
    cout << "Average Search Depth: " << tree.getAverageSearchDepth() << endl;

    Command.close();
    // tree.display();

    // tree.insert(57);
    // printf("%d ", 57);
    // tree.insert(31);
    // printf("%d ", 31);
    // tree.insert(72);
    // printf("%d ", 72);
    // tree.insert(44);
    // printf("%d ", 44);
    // tree.insert(69);
    // printf("%d ", 69);
    // tree.insert(83);
    // printf("%d ", 83);

    // cout << "Tree after insertions: ";
    // tree.display();
    // cout << "Total rotations: " << tree.getRotationCount() << endl;

    // // tree.search(44);
    // // cout << "Tree after splaying 40: ";
    // // tree.display();

    // // tree.remove(31);
    // // cout << "Tree after deleting 30: ";
    // // tree.display();

    return 0;
}
