#ifndef SPLAYTREE_H
#define SPLAYTREE_H

#include <iostream>
using namespace std;

class SplayTree {
    private:
        int rotationCount;
        int totalSearchDepth;
        int searchCount;
        struct Node {
            int key;
            Node* left;
            Node* right;
            int weight;
            Node(int k) {
                key = k;
                left = nullptr;
                right = nullptr;
                weight = 1;
            }
        };

        Node* root;
    
        Node* rotateRight(Node* x);
        Node* rotateLeft(Node* x);
        Node* splay(Node* root, int key);
        Node* topDownSplay(Node* root, int key);
        Node* insertNode(Node* root, int key);
        Node* deleteNode(Node* root, int key);
        Node* semiSplay(Node* root, int key, int currentDepth, int depthLimit);
        Node* weightedSplay(Node* root, int key);
        void printTree(Node* root, int space);
        

    public:
        SplayTree();
        void insert(int key);
        void remove(int key);
        bool search(int key);
        void display();
        int getRotationCount();
        int getAverageSearchDepth();
};

#endif 
